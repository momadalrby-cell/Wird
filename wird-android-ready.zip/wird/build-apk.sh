#!/usr/bin/env bash
# One-shot: installs deps, builds web, creates Android project, outputs wird-debug.apk
# Requirements: Node 18+, JDK 17 or 21, Android SDK (ANDROID_HOME set, platform 34 + build-tools)
set -euo pipefail
cd "$(dirname "$0")"

: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "$ANDROID_HOME" ] || [ ! -d "$ANDROID_HOME" ]; then
  echo "ERROR: set ANDROID_HOME to your Android SDK folder (Android Studio > SDK Manager)." >&2
  exit 1
fi

[ -d node_modules ] || npm install
npm run build
[ -d android ] || npx cap add android
echo "sdk.dir=$ANDROID_HOME" > android/local.properties
node scripts/prepare-android.mjs
npx cap sync android
node scripts/prepare-android.mjs
(cd android && ./gradlew assembleDebug)
cp android/app/build/outputs/apk/debug/app-debug.apk ./wird-debug.apk
echo "Done -> $(pwd)/wird-debug.apk"
