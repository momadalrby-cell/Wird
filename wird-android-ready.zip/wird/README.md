# وِرد — Wird

React + TypeScript + Vite، مغلّف بـ Capacitor لإخراج APK.

## بناء APK (محلياً)
المتطلبات: Node 18+، JDK 17 أو 21، Android SDK (`ANDROID_HOME`).

```bash
./build-apk.sh        # الناتج: wird-debug.apk
```

## بناء APK (سحابياً بدون تثبيت شيء)
ارفع المشروع إلى GitHub ← Actions ← "Build APK" ← Run workflow ← حمّل `wird-debug-apk` من Artifacts.

## تشغيل كويب
```bash
npm install && npm run dev
```

## نسخة Release موقّعة
ولّد keystore ثم اضبط signingConfigs في `android/app/build.gradle` وشغّل `npm run android:release`.
