# Tarteel (iqra) — Architecture Documentation

> Reverse-engineered from `base.apk` (com.mmmoussa.iqra v5.82.3, build 424).
> Analysis performed with AndroGuard (pure Python) + manual DEX parsing.
> No protected code, secrets, or keys are reproduced.

## 1. Application Identity

- **Package**: `com.mmmoussa.iqra`
- **App label**: Tarteel (تَرْتِيل)
- **Version**: 5.82.3 (build 424)
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 36
- **Main activity**: `com.mmmoussa.iqra.MainActivity`
- **Type**: React Native (0.7x) app with a Kotlin Multiplatform shared core module (`ai.tarteel.shared`).

## 2. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  React Native UI (JS bundle: assets/index.android.bundle)   │
│  - Screens: Wird, SRS review, Mic recording, Stats, ...     │
│  - Navigation: React Navigation (stack + tabs)               │
│  - State: Redux + TanStack Query                            │
│  - i18n: react-i18next                                     │
├─────────────────────────────────────────────────────────────┤
│  Native bridge (React Native modules)                       │
│  - MicRecordingService, Widgets, Notifee, Firebase, ...     │
├─────────────────────────────────────────────────────────────┤
│  Kotlin Multiplatform shared core (ai.tarteel.shared)       │
│  - wird, srs, session, mic, revision, memorization, ...     │
│  - SQLDelight (SQLite) local cache                          │
│  - Ktor HTTP client                                         │
├─────────────────────────────────────────────────────────────┤
│  Backend: api.tarteel.ai / api.tarteel.io                   │
│  - Auth, profile, wirds, sessions, spot tests, SRS, ...     │
└─────────────────────────────────────────────────────────────┘
```

## 3. Core Modules (Kotlin Multiplatform)

| Module | Classes | Responsibility |
|---|---|---|
| `wird` | 323 | Daily recitation plan (Wird), Quran references (ayah/surah/page/juz/hizb/rub), scheduling, progress tracking, cached iterations |
| `data` | 275 | SQLDelight database: Session, Wird, Mistake, SrsItemState, SpotTest, CachedWirdSession/Iteration, AyahStats, QuranIdStats |
| `srs` | 175 | Spaced Repetition System based on FSRS (Free Spaced Repetition Scheduler) v6. Cards, review logs, recallability, scheduling |
| `session` | 98 | Recitation sessions: recording, syncing to backend, streaks, badges |
| `mic` | 80 | Audio recording (AndroidRecorder), WebSocket streaming to STT server, volume detection |
| `app` | 58 | App state, logging, shared event emitter |
| `revision` | 54 | Revision algorithm: balanced revision, completion calculator, revision buckets |
| `test` | 42 | Spot tests: fetch, parse, sync to backend |
| `stats` | 32 | Ayah stats, Quran ID stats, date-range stats |
| `leaderboard` | 22 | Leaderboard stats calculation and reporting |
| `memorization` | 19 | Memorization entries, stats, WMA calculation |
| `client` | 8 | Ktor HTTP client factory (createTarteelHttpClient) |
| `badge` | 5 | Badge calculation (session + streak badges) |
| `nitro` | 2 | Native calculator bridge |

## 4. Key Classes & Methods

### SrsManager (srs/)
- `initialize(...)` — configure FSRS engine with params
- `calculateSrs()` — run SRS computation
- `getPageReviewPreview(page, ...)` — preview of a page review
- `getRecallability(...)` — card recallability
- `getTodayCoveredAyahs(...)` — today's covered ayahs
- `clearConfig()`, `validateSrsState()`, `diffEngines()`
- `getDefaultFsrs()` — FSRS v6 engine (Fsrs6Engine)

### Fsrs6Engine (srs/)
- `next(card, instant, rating)` — schedule next review
- `forget(card, instant)` — mark as forgotten
- `repeat(card, instant)` — repeat review
- `retrievability(card, instant)` — current retrievability

### WirdGenerator (wird/)
- `startProcessing(...)`, `stopProcessing(...)` — task worker lifecycle
- `launchTaskProcessingWorker(...)` — coroutine worker
- `processTaskAndQueueResult(task)` — process a single wird calculation task
- `calculateSessionProgress(session, ...)` — session progress
- `cacheWirdIteration(...)`, `cacheCurrentWirdIteration(...)`, `cacheAllCurrentWirdIterations(...)`
- `generateWirdSessions(...)`, `getCachedWirdSessions(...)`
- `getTodaysWirdsProgress(...)`, `getValidCachedWirdIteration(...)`
- `getWirdCalculationResult(wird, iteration)` — cached calculation

### SessionManager (session/)
- `getSessions(...)`, `getFirstSessionBatch(...)`, `getNextSessionBatch(...)`
- `parseSessionsResponse(...)`, `postWirds(...)`
- `syncSessions(...)`, `syncWirds(...)`, `syncSessionsWithMutex(...)`
- `uploadUnsyncedSessions(...)`
- `insertOrUpdateSession(...)`, `insertOrUpdateWirds(...)`
- `calculateAndReportLeaderboardStats()`, `calculateEarnedBadges(...)`, `calculateMemorizationStats(...)`
- `calculateSessionStatsWithinDateRange(...)`

### SpotTestManager (test/)
- `getSpotTests(...)`, `getFirstSpotTestBatch(...)`, `getNextSpotTestBatch(...)`
- `parseSpotTestsResponse(...)`, `syncSpotTests(...)`, `syncSpotTestsWithMutex(...)`
- `uploadUnsyncedSpotTests(...)`, `insertOrUpdateSpotTest(...)`

### SharedMicStream (mic/)
- `initialize(...)`, `start(...)`, `stop(...)`, `pause(...)`, `mute()`, `unmute()`, `destroy()`
- `send(...)`, `onAudioData(...)`, `onMessageReceived(...)`, `handleError(...)`
- WebSocketManager: `connect(...)`, `disconnect(...)`, `sendBinaryMessage(...)`, `sendMessage(...)`

### RevisionManager / RevisionAlgorithm / CompletionCalculator (revision/)
- `getRevisionResults(...)`, `getBalancedRevisionResult(...)`
- `calculateRevisionResults(...)`
- `calculateCompletionsWithMpp(...)`, `calculateMppForReviewedAyahs(...)`

### StatsManager (stats/)
- `generateBlankAyahStats()`, `updateAyahStatsFromSessions(...)`, `updateMemorizationStatus(...)`
- `calculateStats(...)`, `getAyahStats()`, `getMaxMemorizationSessionUpdatedAt()`

### BadgeCalculator (badge/)
- `calculateSessionBadges(...)`, `calculateStreakBadges(...)`, `calculateEarnedBadges(...)`

### DBManager (data/)
- `initDB(path, inMemory)`, `db()`, `dbOrNull()`, `closeDB()`, `isInit()`

### TarteelClientKt (client/)
- `createTarteelHttpClient(baseUrl, token)` — Ktor HTTP client with auth, compression, timeouts

## 5. Data Flow

1. **Mic recording**: AndroidRecorder captures PCM audio → SharedMicStream → WebSocketManager streams binary to STT server (`voice-v2.tarteel.io`) → receives transcription JSON → onMessageReceived → updates UI.
2. **Session creation**: After recitation, SessionManager creates a Session row, computes mistakes, inserts into DB.
3. **Sync**: SessionManager.syncSessions() uploads unsynced sessions to backend (`api.tarteel.ai/v1/profile/quran_sessions/`), receives server-side merged data.
4. **Wird generation**: WirdGenerator.startProcessing() launches a coroutine worker that calculates daily wirds (planned ayah ranges) based on user settings, caches results in SQLDelight.
5. **SRS**: SrsManager initializes FSRS v6 engine; review logs are persisted; `calculateSrs()` recomputes card states; recallability computed per card.
6. **Stats**: StatsManager aggregates ayah stats from sessions; memorization stats via WMA.
7. **Revision**: RevisionAlgorithm computes revision results (balanced buckets); CompletionCalculator computes completions with MPP (mistakes per page).
8. **Leaderboard**: LeaderboardStatsCalculator computes monthly stats; reported to backend.
9. **Spot tests**: SpotTestManager fetches batches from backend, syncs results.

## 6. Backend API Endpoints (observed)

Hosts: `api.tarteel.ai`, `api.tarteel.io`, `voice-v2.tarteel.io`, `audio-cdn.tarteel.ai`, `static-cdn.tarteel.ai`, `srs-onboarding.worker.tarteel.ai`, `feedback.tarteel.ai`, `pl-cms.tarteel.ai`, `download.tarteel.ai`, `get.tarteel.ai`

Endpoints:
- Auth: `v1/account/authenticate/`, `v1/account/create/agent/`, `v1/account/verify`, `v1/account/switch_to_email_login/{start,finish}`, `v1/account/activate_trial_offer/`, `v1/account/heartbeat/engage/`, `v1/account/social_auth_create_account`, `v1/account/delete`, `v1/account/resend_verification_code`, `v1/account/finish_password_reset`
- Profile: `v1/profile/preferences`, `v1/profile/bookmarks`, `v1/profile/mistakes`, `v1/profile/wirds`, `v1/profile/quran_sessions`, `v1/profile/sessions`, `v1/profile/spot_test`, `v1/profile/badges`, `v1/profile/searches`, `v1/profile/shared_ayahs`, `v1/profile/family_group/invite/accept`, `v1/profile/community_group/{join,invite_lookup}`, `v1/profile/srs_onboarding`, `v1/profile/srs_settings`, `v1/profile/feedback`, `v1/profile/recordings`, `v1/profile/manual_memorization_entries`, `v1/profile/highlight_cards`, `v1/profile/store_device_state`, `v1/profile/user_session_audio`, `v1/profile/hydrate`
- Leaderboard: `v1/leaderboards/report_stats/`
- AAD: `v1/aad/schedule`
- Alim: `v1/alim/apply/status`, `v1/alim/cancel`
- Mobile: `v1/mobile/minimum-supported-version`

## 7. Libraries & Dependencies

- React Native, React Navigation, Expo
- Reanimated, AsyncStorage
- Redux Toolkit, TanStack Query
- react-i18next, date-fns
- Ktor (HTTP client), SQLDelight (DB), kotlinx.serialization, kotlinx.coroutines, kotlinx.datetime
- Firebase (messaging, analytics), Sentry, Mixpanel
- RevenueCat (billing), Intercom (support), Notifee (notifications)
- Media3 (audio playback), Coil (image loading)
- FSRS (tsfsrs6) — spaced repetition
- OkHttp (HTTP)

## 8. Multi-part Chunking

- Audio streaming uses WebSocket binary frames (chunked PCM).
- Wird calculation uses a task queue (`WirdCalculationTask`) processed by a coroutine worker (`launchTaskProcessingWorker`).
- Session sync uses batched uploads (`getFirstSessionBatch`, `getNextSessionBatch`).
- No file-based multi-part chunking (upload/download) was observed in the analyzed code paths. The "chunking" is at the level of audio frames and task queues.

## 9. Error Handling & Retry

- `MicStreamException`, `ConnectionClosedException`, `RecorderInitializationException` — typed exceptions for mic failures.
- `EntitySyncError`, `EntitySyncResult` — sync result types with error info.
- `syncSessionsWithMutex`, `syncSpotTestsWithMutex` — mutex-protected sync to avoid concurrent conflicts.
- `uploadUnsyncedSessions`, `uploadUnsyncedSpotTests` — retry unsynced entities.
- HTTP client configured with timeouts (Ktor HttpTimeout plugin).
- `LeaderBoardStatsSyncError` — typed error for leaderboard sync.

## 10. Limitations of Analysis

- The React Native JS bundle is minified; screen names and component hierarchy could not be fully recovered.
- Native module implementations (Java/Kotlin) for widgets, services, and Notifee are present but their internal logic is partially obfuscated by R8.
- The backend API contract (request/response schemas) is not fully recoverable from the client alone.
- No decompilation of native `.so` libraries was performed.
- UI layout XML and resources were not fully decoded.
