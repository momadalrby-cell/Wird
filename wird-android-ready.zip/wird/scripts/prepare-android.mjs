// Runs after `cap add android` / `cap sync`. Idempotent.
import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const res = path.join(root, 'android/app/src/main/res')
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml')

if (!fs.existsSync(manifestPath)) {
  console.error('android/ not found. Run: npm run android:add')
  process.exit(1)
}

// 1) Permissions (microphone for recitation sessions)
let manifest = fs.readFileSync(manifestPath, 'utf8')
const perms = [
  'android.permission.INTERNET',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS',
]
for (const p of perms) {
  if (!manifest.includes(`android:name="${p}"`)) {
    manifest = manifest.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`)
  }
}
if (!manifest.includes('android.hardware.microphone')) {
  manifest = manifest.replace(
    '</manifest>',
    '    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n</manifest>',
  )
}
fs.writeFileSync(manifestPath, manifest)

// 2) Launcher icons
const iconsRoot = path.join(root, 'resources/android')
if (fs.existsSync(iconsRoot)) {
  for (const dir of fs.readdirSync(iconsRoot)) {
    const dest = path.join(res, dir)
    fs.mkdirSync(dest, { recursive: true })
    for (const f of fs.readdirSync(path.join(iconsRoot, dir))) {
      fs.copyFileSync(path.join(iconsRoot, dir, f), path.join(dest, f))
    }
  }
}

// 3) Adaptive icon background color
const bg = path.join(res, 'values/ic_launcher_background.xml')
if (fs.existsSync(bg)) {
  fs.writeFileSync(
    bg,
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F1419</color>\n</resources>\n',
  )
}

console.log('Android project prepared.')
