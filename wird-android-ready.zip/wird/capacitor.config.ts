import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.wird.app',
  appName: 'وِرد',
  webDir: 'dist',
  backgroundColor: '#0f1419',
  android: {
    allowMixedContent: false,
  },
}

export default config
