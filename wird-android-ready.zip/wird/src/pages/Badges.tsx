import { useEffect, useState } from 'react'
import { db, Badge } from '../db'

const BADGE_DEFS: Badge[] = [
  { id: 'streak7', title: '🔥 7 أيام متتالية', desc: 'حفظ 7 أيام متتالية', earned: false },
  { id: 'ayahs100', title: '📖 100 آية', desc: 'مراجعة 100 آية', earned: false },
  { id: 'accuracy90', title: '🎯 دقة 90%+', desc: 'متوسط دقة 90% فأكثر', earned: false },
  { id: 'sessions10', title: '🎙️ 10 جلسات', desc: 'إكمال 10 جلسات', earned: false },
  { id: 'srs50', title: '🧠 50 بطاقة SRS', desc: '50 بطاقة في SRS', earned: false },
  { id: 'mistakes0', title: '✨ بدون أخطاء', desc: 'جلسة بدون أخطاء', earned: false },
]

export default function BadgesPage() {
  const [badges, setBadges] = useState<Badge[]>(BADGE_DEFS)
  const [sessions, setSessions] = useState<number>(0)

  useEffect(() => {
    (async () => {
      await db.badges.bulkPut(BADGE_DEFS.map((b) => ({ ...b, earned: false })))
      const stored = await db.badges.toArray()
      const sess = await db.sessions.toArray() as any[]
      setSessions(sess.length)
      // compute earned
      const earned = new Set<string>()
      if (sess.length >= 10) earned.add('sessions10')
      const totalAyahs = sess.reduce((a: number, s: any) => a + s.transcript.split(' ').length, 0)
      if (totalAyahs >= 100) earned.add('ayahs100')
      const avgAcc = sess.length ? sess.reduce((a: number, s: any) => a + s.accuracy, 0) / sess.length : 0
      if (avgAcc >= 0.9 && sess.length > 0) earned.add('accuracy90')
      const srsCount = await db.srsCards.count()
      if (srsCount >= 50) earned.add('srs50')
      if (sess.some((s) => s.mistakes.length === 0 && s.durationSec > 0)) earned.add('mistakes0')
      // streak
      const days = new Set(sess.map((s: any) => new Date(s.startedAt).toISOString().slice(0, 10)))
      if (days.size >= 7) earned.add('streak7')
      const updated = stored.map((b: any) => ({ ...b, earned: earned.has(b.id), earnedAt: earned.has(b.id) ? Date.now() : undefined }))
      await db.badges.bulkPut(updated)
      setBadges(updated)
    })()
  }, [])

  return (
    <div>
      <div className="card">
        <h2>🏆 الشارات والإنجازات (مجانية)</h2>
        <p style={{ color: '#8b949e' }}>الجلسات: {sessions}</p>
        <ul className="list">
          {badges.map((b) => (
            <li key={b.id}>
              <span>{b.title} — {b.desc}</span>
              <span className="badge">{b.earned ? '✅ مكتسبة' : '🔒 قيد التقدم'}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
