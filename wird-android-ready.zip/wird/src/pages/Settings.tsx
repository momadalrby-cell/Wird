import { useEffect, useState } from 'react'
import { getSetting, setSetting } from '../db'

export default function SettingsPage() {
  const [reciter, setReciter] = useState('alafasy')
  const [dailyGoal, setDailyGoal] = useState('5')
  const [notifications, setNotifications] = useState(true)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    (async () => {
      setReciter(await getSetting('reciter', 'alafasy'))
      setDailyGoal(await getSetting('dailyGoal', '5'))
      setNotifications(await getSetting('notifications', true))
    })()
  }, [])

  const save = async () => {
    await setSetting('reciter', reciter)
    await setSetting('dailyGoal', dailyGoal)
    await setSetting('notifications', notifications)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div>
      <div className="card">
        <h2>⚙️ الإعدادات (جميع الميزات مجانية)</h2>
        <div className="form-group">
          <label>القارئ</label>
          <select value={reciter} onChange={(e) => setReciter(e.target.value)}>
            <option value="alafasy">مشاري العفاسي</option>
            <option value="husary">محمود خليل الحصري</option>
            <option value="minshawi">محمد صديق المنشاوي</option>
          </select>
        </div>
        <div className="form-group">
          <label>الهدف اليومي (صفحات)</label>
          <input type="number" value={dailyGoal} onChange={(e) => setDailyGoal(e.target.value)} />
        </div>
        <div className="form-group">
          <label>
            <input type="checkbox" checked={notifications} onChange={(e) => setNotifications(e.target.checked)} style={{ width: 'auto', marginLeft: '0.5rem' }} />
            تفعيل الإشعارات
          </label>
        </div>
        <button className="btn" onClick={save}>حفظ</button>
        {saved && <span style={{ color: '#3fb950', marginRight: '1rem' }}>✅ تم الحفظ</span>}
      </div>
      <div className="card">
        <h2>ℹ️ معلومات</h2>
        <ul className="list">
          <li><span>التطبيق</span><span>وِرد — Wird</span></li>
          <li><span>الاشتراكات</span><span>لا توجد — جميع الميزات مجانية</span></li>
          <li><span>قاعدة البيانات</span><span>IndexedDB (محلي)</span></li>
          <li><span>مصدر Quran</span><span>api.alquran.cloud (Uthmani)</span></li>
        </ul>
      </div>
    </div>
  )
}
