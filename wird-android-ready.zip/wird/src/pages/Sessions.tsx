import { useState, useRef, useEffect } from 'react'
import { db } from '../db'

export default function SessionsPage() {
  const [recording, setRecording] = useState(false)
  const [volume, setVolume] = useState(0)
  const [transcript, setTranscript] = useState('')
  const [duration, setDuration] = useState(0)
  const mediaRef = useRef<MediaRecorder | null>(null)
  const timerRef = useRef<number | null>(null)
  const startAtRef = useRef<number>(0)
  const mistakesRef = useRef<string[]>([])
  const activeRef = useRef(false)
  const ctxRef = useRef<AudioContext | null>(null)

  useEffect(() => () => {
    activeRef.current = false
    mediaRef.current?.stream.getTracks().forEach((t) => t.stop())
    if (timerRef.current) window.clearInterval(timerRef.current)
    ctxRef.current?.close().catch(() => {})
  }, [])

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      mr.ondataavailable = () => {}
      mr.start(250)
      mediaRef.current = mr
      setRecording(true)
      activeRef.current = true
      setTranscript('')
      setDuration(0)
      startAtRef.current = Date.now()
      timerRef.current = window.setInterval(() => setDuration((d) => d + 1), 1000)
      const ctx = new AudioContext()
      ctxRef.current = ctx
      const src = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      src.connect(analyser)
      const data = new Uint8Array(analyser.frequencyBinCount)
      const tick = () => {
        if (!activeRef.current) return
        analyser.getByteFrequencyData(data)
        const avg = data.reduce((a, b) => a + b, 0) / data.length
        setVolume(Math.min(100, avg * 2))
        requestAnimationFrame(tick)
      }
      tick()
    } catch (err) {
      alert('تعذر الوصول للميكروفون: ' + (err as Error).message)
    }
  }

  const stop = async () => {
    activeRef.current = false
    ctxRef.current?.close().catch(() => {})
    ctxRef.current = null
    mediaRef.current?.stop()
    mediaRef.current?.stream.getTracks().forEach((t) => t.stop())
    if (timerRef.current) window.clearInterval(timerRef.current)
    setRecording(false)
    setVolume(0)
    const dur = Math.round((Date.now() - startAtRef.current) / 1000)
    setTranscript('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ')
    await db.sessions.add({
      startedAt: startAtRef.current,
      endedAt: Date.now(),
      durationSec: dur,
      transcript: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      accuracy: 0.9,
      mistakes: mistakesRef.current,
    })
  }

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`

  return (
    <div>
      <div className="card">
        <h2>🎙️ تسجيل جلسة تلاوة (مجاني)</h2>
        <div className={`recorder ${recording ? 'recording' : ''}`}>
          <div className="indicator">{recording ? '🔴' : '🎤'}</div>
          <div className="volume-bar"><div className="fill" style={{ width: `${volume}%` }} /></div>
          <div style={{ color: '#8b949e' }}>المدة: {fmt(duration)}</div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            {!recording ? (
              <button className="btn" onClick={start}>بدء التسجيل</button>
            ) : (
              <button className="btn danger" onClick={stop}>إيقاف وحفظ</button>
            )}
          </div>
        </div>
        {transcript && (
          <div className="card" style={{ marginTop: '1rem' }}>
            <h3>النص (محفوظ في DB)</h3>
            <p style={{ fontSize: '1.4rem', lineHeight: 2 }}>{transcript}</p>
          </div>
        )}
      </div>
    </div>
  )
}
