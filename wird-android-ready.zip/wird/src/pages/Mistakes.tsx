import { useEffect, useState } from 'react'
import { db, Mistake } from '../db'
import { SURAH_LIST } from '../quran'

export default function MistakesPage() {
  const [mistakes, setMistakes] = useState<Mistake[]>([])
  const load = async () => setMistakes(await db.mistakes.orderBy('createdAt').reverse().toArray())
  useEffect(() => { load() }, [])
  const resolve = async (id: number) => { await db.mistakes.update(id, { resolved: true }); await load() }
  const remove = async (id: number) => { await db.mistakes.delete(id); await load() }
  return (
    <div>
      <div className="card">
        <h2>📝 الأخطاء المسجلة</h2>
        <p style={{ color: '#8b949e' }}>المجموع: {mistakes.length} · غير محلولة: {mistakes.filter((m) => !m.resolved).length}</p>
        <ul className="list">
          {mistakes.map((m) => (
            <li key={m.id}>
              <span>{SURAH_LIST[m.surah - 1]?.name} — {m.ayah}: {m.note}</span>
              <span style={{ display: 'flex', gap: '0.5rem' }}>
                {!m.resolved && <button className="btn" style={{ padding: '0.25rem 0.6rem', fontSize: '0.8rem' }} onClick={() => resolve(m.id!)}>تحديد كمحلول</button>}
                <button className="btn danger" style={{ padding: '0.25rem 0.6rem', fontSize: '0.8rem' }} onClick={() => remove(m.id!)}>حذف</button>
                <span className="badge">{m.resolved ? '✅ محلول' : '⚠️ مفتوح'}</span>
              </span>
            </li>
          ))}
        </ul>
        {mistakes.length === 0 && <p style={{ color: '#8b949e' }}>لا توجد أخطاء مسجلة.</p>}
      </div>
    </div>
  )
}
