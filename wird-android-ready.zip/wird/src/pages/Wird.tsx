import { useEffect, useState } from 'react'
import { db, WirdItem } from '../db'
import { SURAH_LIST } from '../quran'

const today = new Date().toISOString().slice(0, 10)

export default function WirdPage() {
  const [items, setItems] = useState<WirdItem[]>([])
  const load = async () => setItems(await db.wirdItems.where('date').equals(today).toArray())
  useEffect(() => { load() }, [])
  const nameOf = (n: number) => SURAH_LIST.find((s) => s.number === n)?.name ?? `سورة ${n}`
  const toggle = async (id: number, completed: boolean) => { await db.wirdItems.update(id, { completed: !completed }); await load() }
  return (
    <div>
      <div className="card">
        <h2>📖 الورد اليومي</h2>
        <p style={{ color: '#8b949e' }}>تُدار locally — بدون اشتراك</p>
        {items.length === 0 && <p style={{ color: '#8b949e' }}>لا توجد أوراد اليوم. أضف من صفحة "الخطة".</p>}
        <ul className="list">
          {items.map((w) => (
            <li key={w.id} style={{ cursor: 'pointer' }} onClick={() => toggle(w.id!, w.completed)}>
              <span>{nameOf(w.surah)} — آيات {w.ayahStart}-{w.ayahEnd}</span>
              <span className="badge">{w.completed ? '✓ مكتمل' : 'قيد التنفيذ'}</span>
            </li>
          ))}
        </ul>
        {items.length > 0 && (
          <div style={{ marginTop: '1rem' }}>
            <div className="progress"><div className="fill" style={{ width: `${(items.filter((i) => i.completed).length / items.length) * 100}%` }} /></div>
          </div>
        )}
      </div>
    </div>
  )
}
