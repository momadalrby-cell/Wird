import { useEffect, useState } from 'react'
import { db, WirdItem } from '../db'

export default function Dashboard() {
  const [streak, setStreak] = useState(0)
  const [sessions, setSessions] = useState(0)
  const [reviewedAyahs, setReviewedAyahs] = useState(0)
  const [dueCards, setDueCards] = useState(0)
  const [todayWirds, setTodayWirds] = useState<WirdItem[]>([])

  useEffect(() => {
    (async () => {
      const today = new Date().toISOString().slice(0, 10)
      const wirds = await db.wirdItems.where('date').equals(today).toArray()
      setTodayWirds(wirds)
      const sess = await db.sessions.toArray()
      setSessions(sess.length)
      const days = new Set(sess.map((s: any) => new Date(s.startedAt).toISOString().slice(0, 10)))
      setStreak(days.size)
      setReviewedAyahs(sess.reduce((a: number, s: any) => a + s.transcript.split(' ').filter(Boolean).length, 0))
      const now = Date.now()
      setDueCards(await db.srsCards.where('due').belowOrEqual(now).count())
    })()
  }, [])

  return (
    <div>
      <div className="card">
        <h2>📊 لوحة التحكم — وِرد</h2>
        <div className="stat-grid">
          <div className="stat-box"><div className="value">{streak}</div><div className="label">أيام متتالية</div></div>
          <div className="stat-box"><div className="value">{reviewedAyahs}</div><div className="label">آيات مراجعة</div></div>
          <div className="stat-box"><div className="value">{dueCards}</div><div className="label">بطاقات SRS due</div></div>
          <div className="stat-box"><div className="value">{sessions}</div><div className="label">جلسات</div></div>
        </div>
      </div>
      <div className="card">
        <h2>📖 ورد اليوم</h2>
        {todayWirds.length === 0 && <p style={{ color: '#8b949e' }}>لا توجد أوراد. أضف من صفحة "الخطة".</p>}
        <ul className="list">
          {todayWirds.map((w) => (
            <li key={w.id}>
              <span>سورة {w.surah} — {w.ayahStart}-{w.ayahEnd}</span>
              <span className="badge">{w.completed ? '✓ مكتمل' : 'قيد التنفيذ'}</span>
            </li>
          ))}
        </ul>
        {todayWirds.length > 0 && (
          <div style={{ marginTop: '1rem' }}>
            <div className="progress"><div className="fill" style={{ width: `${(todayWirds.filter((i) => i.completed).length / todayWirds.length) * 100}%` }} /></div>
          </div>
        )}
      </div>
      <div className="card">
        <h2>🧠 مراجعة SRS</h2>
        <p>لديك {dueCards} بطاقة due للمراجعة اليوم.</p>
      </div>
    </div>
  )
}
