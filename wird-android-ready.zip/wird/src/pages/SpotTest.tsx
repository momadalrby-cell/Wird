import { useEffect, useState } from 'react'
import { db } from '../db'
import { SURAH_LIST, fetchSurahAyahs } from '../quran'

export default function SpotTestPage() {
  const [surah, setSurah] = useState(1)
  const [ayahs, setAyahs] = useState<{ number: number; text: string }[]>([])
  const [hidden, setHidden] = useState<number | null>(null)
  const [guess, setGuess] = useState('')
  const [result, setResult] = useState<string | null>(null)
  const [score, setScore] = useState({ ok: 0, total: 0 })

  useEffect(() => { fetchSurahAyahs(surah).then(setAyahs) }, [surah])

  const start = () => {
    if (!ayahs.length) return
    const i = Math.floor(Math.random() * ayahs.length)
    setHidden(i)
    setGuess('')
    setResult(null)
  }
  const check = async () => {
    if (hidden === null) return
    const a = ayahs[hidden]
    const ok = guess.trim() === a.text.trim()
    setResult(ok ? '✅ صحيح' : `❌ خطأ. الإجابة: ${a.text}`)
    setScore((s) => ({ ok: s.ok + (ok ? 1 : 0), total: s.total + 1 }))
    if (!ok) {
      await db.mistakes.add({ surah, ayah: a.number, note: `اختبار: ${guess}`, createdAt: Date.now(), resolved: false })
    }
  }

  return (
    <div>
      <div className="card">
        <h2>🎯 اختبار التسميع العشوائي (مجاني)</h2>
        <div className="form-group"><label>السورة</label>
          <select value={surah} onChange={(e) => setSurah(+e.target.value)}>
            {SURAH_LIST.map((s) => <option key={s.number} value={s.number}>{s.number}. {s.name}</option>)}
          </select>
        </div>
        <button className="btn" onClick={start}>🎲 بدء اختبار</button>
        {hidden !== null && ayahs[hidden] && (
          <div style={{ marginTop: '1rem' }}>
            <p style={{ color: '#8b949e' }}>أكمل الآية:</p>
            <p style={{ fontSize: '1.3rem', lineHeight: 2, marginBottom: '0.5rem' }}>
              {ayahs[hidden].text.split(' ').slice(0, Math.ceil(ayahs[hidden].text.split(' ').length / 2)).join(' ')} …
            </p>
            <textarea value={guess} onChange={(e) => setGuess(e.target.value)} placeholder="اكتب بقية الآية" />
            <button className="btn" onClick={check} style={{ marginTop: '0.5rem' }}>تحقق</button>
            {result && <p style={{ marginTop: '0.5rem' }}>{result}</p>}
          </div>
        )}
        <p style={{ marginTop: '1rem', color: '#8b949e' }}>النتيجة: {score.ok}/{score.total}</p>
      </div>
    </div>
  )
}
