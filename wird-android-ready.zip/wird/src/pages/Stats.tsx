import { useEffect, useState } from 'react'
import { db } from '../db'

export default function StatsPage() {
  const [stats, setStats] = useState<{ label: string; value: string }[]>([])
  const [badges, setBadges] = useState<string[]>([])

  useEffect(() => {
    (async () => {
      const sessions = await db.sessions.toArray()
      const wirds = await db.wirdItems.toArray()
      const srs = await db.srsCards.count()
      const mistakes = await db.mistakes.count()
      const completedWirds = wirds.filter((w: any) => w.completed).length
      const totalAyahs = sessions.reduce((a: number, s: any) => a + s.transcript.split(' ').filter(Boolean).length, 0)
      const avgAcc = sessions.length ? sessions.reduce((a: number, s: any) => a + s.accuracy, 0) / sessions.length : 0
      const days = new Set(sessions.map((s: any) => new Date(s.startedAt).toISOString().slice(0, 10))).size
      setStats([
        { label: 'إجمالي الجلسات', value: String(sessions.length) },
        { label: 'آيات مراجعة', value: String(totalAyahs) },
        { label: 'متوسط الدقة', value: `${Math.round(avgAcc * 100)}%` },
        { label: 'أيام متتالية', value: String(days) },
        { label: 'بطاقات SRS', value: String(srs) },
        { label: 'أخطاء مسجلة', value: String(mistakes) },
        { label: 'أواراد مكتملة', value: `${completedWirds}/${wirds.length}` },
      ])
      const b: string[] = []
      if (days >= 7) b.push('🔥 7 أيام متتالية')
      if (totalAyahs >= 100) b.push('📖 100 آية')
      if (avgAcc >= 0.9 && sessions.length > 0) b.push('🎯 دقة 90%+')
      if (sessions.length >= 10) b.push('🎙️ 10 جلسات')
      if (srs >= 50) b.push('🧠 50 بطاقة SRS')
      setBadges(b)
    })()
  }, [])

  return (
    <div>
      <div className="card">
        <h2>📊 الإحصائيات (بيانات حقيقية من DB)</h2>
        <div className="stat-grid">
          {stats.map((s) => (
            <div key={s.label} className="stat-box">
              <div className="value">{s.value}</div>
              <div className="label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="card">
        <h2>🏆 الشارات المكتسبة</h2>
        {badges.length === 0 && <p style={{ color: '#8b949e' }}>لا توجد شارات بعد.</p>}
        <ul className="list">
          {badges.map((b) => <li key={b}><span>{b}</span><span className="badge">مكتسبة</span></li>)}
        </ul>
      </div>
    </div>
  )
}
