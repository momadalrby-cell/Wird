import { useEffect, useState } from 'react'
import { db, WirdItem } from '../db'

const today = new Date().toISOString().slice(0, 10)

export default function PlanPage() {
  const [items, setItems] = useState<WirdItem[]>([])
  const [surah, setSurah] = useState(1)
  const [start, setStart] = useState(1)
  const [end, setEnd] = useState(5)

  const load = async () => {
    const all = await db.wirdItems.where('date').equals(today).toArray()
    setItems(all)
  }
  useEffect(() => { load() }, [])

  const add = async () => {
    await db.wirdItems.add({ surah, ayahStart: start, ayahEnd: end, completed: false, date: today })
    await load()
  }
  const toggle = async (id: number, completed: boolean) => {
    await db.wirdItems.update(id, { completed: !completed })
    await load()
  }
  const remove = async (id: number) => {
    await db.wirdItems.delete(id)
    await load()
  }

  return (
    <div>
      <div className="card">
        <h2>🗓️ خطة الورد (جميع الميزات مجانية)</h2>
        <div className="form-group"><label>السورة (رقم)</label><input type="number" value={surah} onChange={(e) => setSurah(+e.target.value)} min={1} max={114} /></div>
        <div className="form-group"><label>من آية</label><input type="number" value={start} onChange={(e) => setStart(+e.target.value)} min={1} /></div>
        <div className="form-group"><label>إلى آية</label><input type="number" value={end} onChange={(e) => setEnd(+e.target.value)} min={1} /></div>
        <button className="btn" onClick={add}>➕ إضافة ورد</button>
      </div>
      <div className="card">
        <h3>ورد اليوم ({today})</h3>
        {items.length === 0 && <p style={{ color: '#8b949e' }}>لا توجد أوراد. أضف وردًا أعلاه.</p>}
        <ul className="list">
          {items.map((w) => (
            <li key={w.id}>
              <span>سورة {w.surah} — آيات {w.ayahStart}-{w.ayahEnd}</span>
              <span style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn" style={{ padding: '0.25rem 0.6rem', fontSize: '0.85rem' }} onClick={() => toggle(w.id!, w.completed)}>{w.completed ? '✓ مكتمل' : 'تحديد كمكتمل'}</button>
                <button className="btn danger" style={{ padding: '0.25rem 0.6rem', fontSize: '0.85rem' }} onClick={() => remove(w.id!)}>حذف</button>
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
