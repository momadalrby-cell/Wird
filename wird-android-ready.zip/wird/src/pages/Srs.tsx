import { useEffect, useState } from 'react'
import { db, SrsCard } from '../db'
import { SURAH_LIST } from '../quran'

export default function SrsPage() {
  const [cards, setCards] = useState<SrsCard[]>([])
  const [idx, setIdx] = useState(0)
  const [revealed, setRevealed] = useState(false)

  const load = async () => {
    const now = Date.now()
    const due = await db.srsCards.where('due').belowOrEqual(now).toArray()
    setCards(due.length ? due : await db.srsCards.limit(10).toArray())
  }
  useEffect(() => { load() }, [])

  const review = async (rating: number) => {
    const c = cards[idx]
    if (!c?.id) return
    // FSRS-lite: update stability/difficulty
    const now = Date.now()
    const r = Math.max(0, Math.min(1, rating / 4))
    const newStability = c.stability * (1 + 0.5 * r) + (rating === 1 ? 0 : 1)
    const newDifficulty = Math.max(1, Math.min(10, c.difficulty + (rating < 2 ? 0.5 : -0.2)))
    const intervalDays = Math.max(1, Math.round(newStability))
    await db.srsCards.update(c.id, {
      stability: newStability,
      difficulty: newDifficulty,
      reps: c.reps + 1,
      lapses: rating === 1 ? c.lapses + 1 : c.lapses,
      lastReview: now,
      due: now + intervalDays * 86400000,
    })
    setRevealed(false)
    setIdx((i) => (i + 1) % Math.max(1, cards.length))
    await load()
  }

  const addSample = async () => {
    const samples = [
      { surah: 1, ayah: 1, text: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ' },
      { surah: 1, ayah: 2, text: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ' },
      { surah: 1, ayah: 3, text: 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ' },
    ]
    for (const s of samples) {
      await db.srsCards.add({ ...s, due: Date.now(), stability: 1, difficulty: 5, reps: 0, lapses: 0, lastReview: 0 })
    }
    await load()
  }

  const card = cards[idx] ?? cards[0]
  return (
    <div>
      <div className="card">
        <h2>🧠 مراجعة SRS (FSRS-lite)</h2>
        <p style={{ color: '#8b949e' }}>due: {cards.length} · جميع الميزات مجانية</p>
        {cards.length === 0 && <button className="btn" onClick={addSample}>➕ إضافة بطاقات نموذجية</button>}
        {card && (
          <>
            <div className="flashcard">
              <div className="ayah">{card.text}</div>
              {revealed && <div style={{ marginTop: '1rem', color: '#79c0ff' }}>{SURAH_LIST[card.surah - 1]?.name} — {card.ayah}</div>}
            </div>
            <div style={{ textAlign: 'center', marginTop: '1rem' }}>
              {!revealed ? (
                <button className="btn" onClick={() => setRevealed(true)}>إظهار الإجابة</button>
              ) : (
                <div className="rating-row">
                  {['Again', 'Hard', 'Good', 'Easy'].map((r, i) => (
                    <button key={r} className="rating-btn" onClick={() => review(i + 1)}>{r}</button>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
