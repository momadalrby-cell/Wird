import { useState } from 'react'
import { searchQuran, SURAH_LIST } from '../quran'

export default function SearchPage() {
  const [q, setQ] = useState('')
  const [results, setResults] = useState<{ surah: number; ayah: number; text: string }[]>([])
  const [loading, setLoading] = useState(false)

  const run = async () => {
    if (!q.trim()) return
    setLoading(true)
    const r = await searchQuran(q.trim())
    setResults(r)
    setLoading(false)
  }

  return (
    <div>
      <div className="card">
        <h2>🔍 البحث في القرآن</h2>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن آية..." onKeyDown={(e) => e.key === 'Enter' && run()} />
          <button className="btn" onClick={run}>بحث</button>
        </div>
        {loading && <p style={{ color: '#8b949e', marginTop: '1rem' }}>جاري البحث...</p>}
        <ul className="list" style={{ marginTop: '1rem' }}>
          {results.map((r, i) => (
            <li key={i}>
              <span style={{ fontSize: '1.1rem', lineHeight: 1.8 }}>{r.text}</span>
              <span className="badge">{SURAH_LIST[r.surah - 1]?.name} — {r.ayah}</span>
            </li>
          ))}
        </ul>
        {!loading && results.length === 0 && q && <p style={{ color: '#8b949e' }}>لا توجد نتائج.</p>}
      </div>
    </div>
  )
}
