import { Routes, Route, NavLink } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import WirdPage from './pages/Wird'
import PlanPage from './pages/Plan'
import SrsPage from './pages/Srs'
import SpotTestPage from './pages/SpotTest'
import SessionsPage from './pages/Sessions'
import StatsPage from './pages/Stats'
import BadgesPage from './pages/Badges'
import SearchPage from './pages/Search'
import MistakesPage from './pages/Mistakes'
import SettingsPage from './pages/Settings'
// import './App.css'

const navItems = [
  { to: '/', label: 'الرئيسية', icon: '🏠' },
  { to: '/wird', label: 'الورد', icon: '📖' },
  { to: '/plan', label: 'الخطة', icon: '🗓️' },
  { to: '/srs', label: 'المراجعة', icon: '🧠' },
  { to: '/spot', label: 'اختبار', icon: '🎯' },
  { to: '/sessions', label: 'الجلسات', icon: '🎙️' },
  { to: '/stats', label: 'الإحصائيات', icon: '📊' },
  { to: '/badges', label: 'الشارات', icon: '🏆' },
  { to: '/search', label: 'البحث', icon: '🔍' },
  { to: '/mistakes', label: 'الأخطاء', icon: '📝' },
  { to: '/settings', label: 'الإعدادات', icon: '⚙️' },
]

export default function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>وِرد</h1>
        <p className="subtitle">Wird — حفظ ومراجعة القرآن الكريم · جميع الميزات مجانية</p>
      </header>
      <nav className="app-nav">
        {navItems.map((n) => (
          <NavLink key={n.to} to={n.to} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
            <span className="nav-icon">{n.icon}</span>
            <span className="nav-label">{n.label}</span>
          </NavLink>
        ))}
      </nav>
      <main className="app-main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/wird" element={<WirdPage />} />
          <Route path="/plan" element={<PlanPage />} />
          <Route path="/srs" element={<SrsPage />} />
          <Route path="/spot" element={<SpotTestPage />} />
          <Route path="/sessions" element={<SessionsPage />} />
          <Route path="/stats" element={<StatsPage />} />
          <Route path="/badges" element={<BadgesPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/mistakes" element={<MistakesPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Routes>
      </main>
      <footer className="app-footer">
        <small>وِرد — جميع الميزات مجانية بالكامل · لا اشتراكات · لا عمليات شراء</small>
      </footer>
    </div>
  )
}
