export interface Surah { number: number; name: string; englishName: string; revelationType: string; numberOfAyahs: number }
export interface Ayah { number: number; text: string; translation?: string }

const SURAH_NAMES = [
  [1,'الفاتحة','Al-Fatihah','Meccan',7],[2,'البقرة','Al-Baqarah','Medinan',286],[3,'آل عمران','Aal Imran','Medinan',200],[4,'النساء','An-Nisa','Medinan',176],[5,'المائدة','Al-Maidah','Medinan',120],[6,'الأنعام','Al-Anam','Meccan',165],[7,'الأعراف','Al-Araf','Meccan',206],[8,'الأنفال','Al-Anfal','Medinan',75],[9,'التوبة','At-Tawbah','Medinan',129],[10,'يونس','Yunus','Meccan',109],[11,'هود','Hud','Meccan',123],[12,'يوسف','Yusuf','Meccan',111],[13,'الرعد','Ar-Rad','Medinan',43],[14,'إبراهيم','Ibrahim','Meccan',52],[15,'الحجر','Al-Hijr','Meccan',99],[16,'النحل','An-Nahl','Meccan',128],[17,'الإسراء','Al-Isra','Meccan',111],[18,'الكهف','Al-Kahf','Meccan',110],[19,'مريم','Maryam','Meccan',98],[20,'طه','Taha','Meccan',135],[21,'الأنبياء','Al-Anbiya','Meccan',112],[22,'الحج','Al-Hajj','Medinan',78],[23,'المؤمنون','Al-Muminun','Meccan',118],[24,'النور','An-Nur','Medinan',64],[25,'الفرقان','Al-Furqan','Meccan',77],[26,'الشعراء','Ash-Shuara','Meccan',227],[27,'النمل','An-Naml','Meccan',93],[28,'القصص','Al-Qasas','Meccan',88],[29,'العنكبوت','Al-Ankabut','Meccan',69],[30,'الروم','Ar-Rum','Meccan',60],[31,'لقمان','Luqman','Meccan',34],[32,'السجدة','As-Sajdah','Meccan',30],[33,'الأحزاب','Al-Ahzab','Medinan',73],[34,'سبأ','Saba','Meccan',54],[35,'فاطر','Fatir','Meccan',45],[36,'يس','Ya-Sin','Meccan',83],[37,'الصافات','As-Saffat','Meccan',182],[38,'ص','Sad','Meccan',88],[39,'الزمر','Az-Zumar','Meccan',75],[40,'غافر','Ghafir','Meccan',85],[41,'فصلت','Fussilat','Meccan',54],[42,'الشورى','Ash-Shura','Meccan',53],[43,'الزخرف','Az-Zukhruf','Meccan',89],[44,'الدخان','Ad-Dukhan','Meccan',59],[45,'الجاثية','Al-Jathiyah','Meccan',37],[46,'الأحقاف','Al-Ahqaf','Meccan',35],[47,'محمد','Muhammad','Medinan',38],[48,'الفتح','Al-Fath','Medinan',29],[49,'الحجرات','Al-Hujurat','Medinan',18],[50,'ق','Qaf','Meccan',45],[51,'الذاريات','Adh-Dhariyat','Meccan',60],[52,'الطور','At-Tur','Meccan',49],[53,'النجم','An-Najm','Meccan',62],[54,'القمر','Al-Qamar','Meccan',55],[55,'الرحمن','Ar-Rahman','Medinan',78],[56,'الواقعة','Al-Waqiah','Meccan',96],[57,'الحديد','Al-Hadid','Medinan',29],[58,'المجادلة','Al-Mujadila','Medinan',22],[59,'الحشر','Al-Hashr','Medinan',24],[60,'الممتحنة','Al-Mumtahanah','Medinan',13],[61,'الصف','As-Saff','Medinan',14],[62,'الجمعة','Al-Jumuah','Medinan',11],[63,'المنافقون','Al-Munafiqun','Medinan',11],[64,'التغابن','At-Taghabun','Medinan',18],[65,'الطلاق','At-Talaq','Medinan',12],[66,'التحريم','At-Tahrim','Medinan',12],[67,'الملك','Al-Mulk','Meccan',30],[68,'القلم','Al-Qalam','Meccan',52],[69,'الحاقة','Al-Haqqah','Meccan',52],[70,'المعارج','Al-Maarij','Meccan',44],[71,'نوح','Nuh','Meccan',28],[72,'الجن','Al-Jinn','Meccan',28],[73,'المزمل','Al-Muzzammil','Meccan',20],[74,'المدثر','Al-Muddaththir','Meccan',56],[75,'القيامة','Al-Qiyamah','Meccan',40],[76,'الإنسان','Al-Insan','Medinan',31],[77,'المرسلات','Al-Mursalat','Meccan',50],[78,'النبأ','An-Naba','Meccan',40],[79,'النازعات','An-Naziat','Meccan',46],[80,'عبس','Abasa','Meccan',42],[81,'التكوير','At-Takwir','Meccan',29],[82,'الانفطار','Al-Infitar','Meccan',19],[83,'المطففين','Al-Mutaffifin','Meccan',36],[84,'الانشقاق','Al-Inshiqaq','Meccan',25],[85,'البروج','Al-Buruj','Meccan',22],[86,'الطارق','At-Tariq','Meccan',17],[87,'الأعلى','Al-Ala','Meccan',19],[88,'الغاشية','Al-Ghashiyah','Meccan',26],[89,'الفجر','Al-Fajr','Meccan',30],[90,'البلد','Al-Balad','Meccan',20],[91,'الشمس','Ash-Shams','Meccan',15],[92,'الليل','Al-Layl','Meccan',21],[93,'الضحى','Ad-Duha','Meccan',11],[94,'الشرح','Ash-Sharh','Meccan',8],[95,'التين','At-Tin','Meccan',8],[96,'العلق','Al-Alaq','Meccan',19],[97,'القدر','Al-Qadr','Meccan',5],[98,'البينة','Al-Bayyinah','Medinan',8],[99,'الزلزلة','Az-Zalzalah','Medinan',8],[100,'العاديات','Al-Adiyat','Meccan',11],[101,'القارعة','Al-Qariah','Meccan',11],[102,'التكاثر','At-Takathur','Meccan',8],[103,'العصر','Al-Asr','Meccan',3],[104,'الهمزة','Al-Humazah','Meccan',9],[105,'الفيل','Al-Fil','Meccan',5],[106,'قريش','Quraysh','Meccan',4],[107,'الماعون','Al-Maun','Meccan',7],[108,'الكوثر','Al-Kawthar','Meccan',3],[109,'الكافرون','Al-Kafirun','Meccan',6],[110,'النصر','An-Nasr','Medinan',3],[111,'المسد','Al-Masad','Meccan',5],[112,'الإخلاص','Al-Ikhlas','Meccan',4],[113,'الفلق','Al-Falaq','Meccan',5],[114,'الناس','An-Nas','Meccan',6],
].map(([n,ar,en,type,ayahs]) => ({ number:n, name:ar, englishName:en, revelationType:type, numberOfAyahs:ayahs } as Surah))

export const SURAH_LIST: Surah[] = SURAH_NAMES

export async function fetchSurahAyahs(surahNumber: number): Promise<Ayah[]> {
  try {
    const res = await fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/quran-uthmani`)
    const data = await res.json()
    if (data.code === 200 && data.data?.ayahs) {
      return data.data.ayahs.map((a: any) => ({ number: a.numberInSurah, text: a.text }))
    }
  } catch (e) { /* fallback */ }
  return []
}

export async function searchQuran(query: string): Promise<{ surah: number; ayah: number; text: string }[]> {
  try {
    const res = await fetch(`https://api.alquran.cloud/v1/search/${encodeURIComponent(query)}/all/quran-uthmani`)
    const data = await res.json()
    if (data.code === 200 && data.data?.matches) {
      return data.data.matches.slice(0, 50).map((m: any) => ({
        surah: m.surah.number,
        ayah: m.numberInSurah,
        text: m.text,
      }))
    }
  } catch (e) { /* ignore */ }
  return []
}
