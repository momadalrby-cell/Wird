import Dexie, { Table } from 'dexie'

export interface WirdItem { id?: number; surah: number; ayahStart: number; ayahEnd: number; completed: boolean; date: string }
export interface SrsCard { id?: number; surah: number; ayah: number; text: string; due: number; stability: number; difficulty: number; reps: number; lapses: number; lastReview: number }
export interface Session { id?: number; startedAt: number; endedAt?: number; durationSec: number; transcript: string; accuracy: number; mistakes: string[] }
export interface Mistake { id?: number; surah: number; ayah: number; note: string; createdAt: number; resolved: boolean }
export interface Badge { id: string; title: string; desc: string; earned: boolean; earnedAt?: number }
export interface Setting { key: string; value: any }

class WirdDB extends Dexie {
  wirdItems!: Table<WirdItem, number>
  srsCards!: Table<SrsCard, number>
  sessions!: Table<Session, number>
  mistakes!: Table<Mistake, number>
  badges!: Table<Badge, string>
  settings!: Table<Setting, string>
  constructor() {
    super('wird-db')
    this.version(1).stores({
      wirdItems: '++id, date, surah',
      srsCards: '++id, surah, ayah, due',
      sessions: '++id, startedAt',
      mistakes: '++id, surah, ayah, resolved',
      badges: 'id',
      settings: 'key',
    })
  }
}

export const db = new WirdDB()

export async function getSetting(key: string, def: any = null) {
  const r = await db.settings.get(key)
  return r ? r.value : def
}
export async function setSetting(key: string, value: any) {
  await db.settings.put({ key, value })
}
